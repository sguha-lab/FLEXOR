
if ("package:FLEXOR" %in% search()){
  ## unload a loaded package without restarting R
  detach("package:FLEXOR", unload=TRUE)
}

devtools::build()

install.packages("../FLEXOR_1.0.0.tar.gz")


