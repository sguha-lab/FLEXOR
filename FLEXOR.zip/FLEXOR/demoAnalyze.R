
rm(list=ls())

# install FLEXOR package
source("building_installing_packages.R")

# load package
library(FLEXOR)

# set runtime parameters
num.random=25
B=100

# load demo dataset
data(demo)

## FLEXOR BALANCING WEIGHTS

output1 = balancing.weights(S, Z, X, method="FLEXOR", naturalGroupProp, num.random)
summary(output1)

## FLEXOR CAUSAL INFERENCES

output2.f %<-% causal.estimate(S, Z, X, Y, B, method="FLEXOR", naturalGroupProp=naturalGroupProp, num.random, gammaMin=1e-3, gammaMax = (1-1e-3), seed=NULL)
summary(output2.f)

## IGO CAUSAL INFERENCES

output2.igo %<-% causal.estimate(S, Z, X, Y, B, method="IGO")
summary(output2.igo)

## IC CAUSAL INFERENCES

output2.ic %<-% causal.estimate(S, Z, X, Y, B, method="IC")
summary(output2.ic)


### SUMMARY FUNCTIONS FOR FLEXOR WEIGHTS
# Stage I: outcome-free analysis for weights
summary(output1)

# Stage II: causal inference
summary(output2.f)



